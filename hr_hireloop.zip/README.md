# 🧭 HireLoop — HR & Candidate Interaction Platform

A full-stack recruitment platform where **HR teams** post jobs and review
ML-ranked applicants, and **candidates** upload resumes and apply to roles —
with automatic resume parsing and machine-learning-based candidate-job
matching.

## Tech Stack

| Layer            | Technology                                              |
|-------------------|----------------------------------------------------------|
| Frontend UI       | **Streamlit** (multi-page app)                            |
| Backend API       | **Flask** (REST API, `/api/*` routes)                     |
| Database          | SQLite (via `sqlite3`, zero-config)                       |
| ML Matching       | **scikit-learn** (TF-IDF vectorizer + cosine similarity)  |
| Data handling     | **pandas**, **NumPy**                                     |
| Visualizations    | **Matplotlib** (bar charts, pie charts in dashboards)     |
| Resume parsing    | **pdfplumber** / **PyPDF2** (PDF) + **python-docx** (DOCX)|
| Auth              | Werkzeug password hashing (salted, never stores plaintext)|

## Features

### For HR / Recruiters
- Register/login with company name
- Post jobs with required skills, minimum experience, and location
- View **all applicants ranked by ML match score** (0–100%)
- See a breakdown per candidate: text similarity, skill overlap, experience fit
- Visual dashboards: applicants-per-job bar chart, status breakdown pie chart
- Update application status (applied → shortlisted → hired/rejected)
- Message candidates directly

### For Candidates
- Register/login
- Upload resume (PDF / DOCX / TXT) — auto-parsed for name, email, phone,
  skills, experience years, and education
- Browse open jobs, search by title/skill
- Apply with one click — instantly see your match score
- Track all applications and their status
- Message HR back

## Project Structure

```
hr_platform/
├── app.py                      # Flask REST API (backend)
├── streamlit_app.py            # Streamlit entry point (login/register + home)
├── requirements.txt
├── .streamlit/config.toml      # Streamlit theme config
├── database/
│   └── db_manager.py           # SQLite schema + connection handling
├── models/
│   └── matcher.py              # scikit-learn TF-IDF matching engine
├── utils/
│   ├── auth.py                 # Registration/login logic, password hashing
│   ├── resume_parser.py        # PDF/DOCX text extraction + entity parsing
│   └── api_client.py           # HTTP client Streamlit uses to call Flask
├── pages/
│   ├── 1_Post_Job.py           # HR: create job postings
│   ├── 2_Manage_Applicants.py  # HR: ranked applicant review + messaging
│   ├── 3_HR_Dashboard.py       # HR: matplotlib analytics
│   ├── 4_My_Resumes.py         # Candidate: upload & view resumes
│   ├── 5_Browse_Jobs.py        # Candidate: search & apply to jobs
│   └── 6_My_Applications.py    # Candidate: track applications + messaging
└── uploads/resumes/            # Uploaded resume files stored here
```

## Setup & Run

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Start the Flask backend (Terminal 1)
```bash
python app.py
```
This runs on `http://localhost:5000` and auto-creates the SQLite database
on first run.

### 3. Start the Streamlit frontend (Terminal 2)
```bash
streamlit run streamlit_app.py
```
This runs on `http://localhost:8501`. **Both servers must be running
simultaneously** — Streamlit is a thin UI layer that calls the Flask API
for all data operations.

### 4. Use the app
Open `http://localhost:8501` in your browser, register as either an
**HR** or **Candidate** account, and start exploring.

## How the ML Matching Works

`models/matcher.py` implements `CandidateJobMatcher`, which scores every
resume against a job posting using three weighted signals:

1. **Text similarity (50%)** — TF-IDF vectors of the resume text and job
   description, compared via cosine similarity. Captures overall semantic
   relevance beyond exact keyword matches.
2. **Skill overlap (35%)** — exact-match ratio of the candidate's parsed
   skills against the job's required skills list.
3. **Experience fit (15%)** — how the candidate's parsed years of
   experience compares to the job's minimum requirement (partial credit
   if under, full credit if met/exceeded).

The final blended score (0–100) is what HR sees in the ranked applicant
list, along with the individual component breakdown and a list of
matched vs. missing skills — so recruiters understand *why* a candidate
scored the way they did, not just the number.

## Notes & Limitations

- The resume parser uses a curated skills taxonomy (`SKILLS_DB` in
  `utils/resume_parser.py`) rather than a heavy NLP/NER model — this
  keeps the app fast and fully offline, but you should extend that list
  for domains outside general tech/software roles.
- SQLite is used for simplicity; for production/multi-user concurrent
  write-heavy use, consider swapping in PostgreSQL (the `db_manager.py`
  abstraction makes this a fairly contained change).
- This is a development setup (Flask's built-in server, no HTTPS). For
  production deployment, put Flask behind a WSGI server (gunicorn) and
  a reverse proxy, and enable HTTPS.
