"""
Flask Backend API for HR-Candidate Interaction Platform
==========================================================
Provides REST endpoints for:
  - Authentication (register/login)
  - Job posting & listing (HR)
  - Resume upload & parsing (Candidate)
  - Job application (Candidate)
  - ML-based candidate ranking (HR)
  - Messaging between HR and Candidate

The Streamlit frontend (streamlit_app.py) talks to this API over HTTP.
This separation demonstrates a realistic full-stack architecture:
Streamlit (UI) -> Flask (API + business logic) -> SQLite (persistence).

Run with: python app.py   (serves on http://localhost:5000)
"""
import os
import sys

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from flask import Flask, request, jsonify
from werkzeug.utils import secure_filename

from database.db_manager import init_db, db_cursor, now_str
from utils.auth import register_user, login_user, get_user_by_id
from utils.resume_parser import parse_resume
from models.matcher import CandidateJobMatcher

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads", "resumes")
ALLOWED_EXTENSIONS = {"pdf", "docx", "doc", "txt"}

app = Flask(__name__)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["MAX_CONTENT_LENGTH"] = 10 * 1024 * 1024  # 10 MB max resume size

matcher = CandidateJobMatcher()

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
init_db()


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def error_response(message, code=400):
    return jsonify({"success": False, "message": message}), code


# ---------------------------------------------------------------------
# Health check
# ---------------------------------------------------------------------
@app.route("/api/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "service": "hr-platform-api"})


# ---------------------------------------------------------------------
# AUTH
# ---------------------------------------------------------------------
@app.route("/api/register", methods=["POST"])
def api_register():
    data = request.get_json(force=True)
    full_name = data.get("full_name", "")
    email = data.get("email", "")
    password = data.get("password", "")
    role = data.get("role", "")
    company_name = data.get("company_name")

    success, message = register_user(full_name, email, password, role, company_name)
    return jsonify({"success": success, "message": message}), (201 if success else 400)


@app.route("/api/login", methods=["POST"])
def api_login():
    data = request.get_json(force=True)
    email = data.get("email", "")
    password = data.get("password", "")

    success, result = login_user(email, password)
    if success:
        return jsonify({"success": True, "user": result})
    return error_response(result, 401)


@app.route("/api/user/<int:user_id>", methods=["GET"])
def api_get_user(user_id):
    user = get_user_by_id(user_id)
    if user is None:
        return error_response("User not found", 404)
    return jsonify({"success": True, "user": user})


# ---------------------------------------------------------------------
# JOBS (HR side)
# ---------------------------------------------------------------------
@app.route("/api/jobs", methods=["POST"])
def create_job():
    data = request.get_json(force=True)
    required = ["hr_id", "title", "description", "required_skills"]
    if not all(k in data for k in required):
        return error_response(f"Missing fields. Required: {required}")

    skills_str = ",".join(s.strip() for s in data["required_skills"] if s.strip())

    with db_cursor(commit=True) as cur:
        cur.execute(
            """INSERT INTO jobs (hr_id, title, description, required_skills,
                                  min_experience, location, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (
                data["hr_id"],
                data["title"],
                data["description"],
                skills_str,
                data.get("min_experience", 0),
                data.get("location", ""),
                now_str(),
            ),
        )
        job_id = cur.lastrowid

    return jsonify({"success": True, "job_id": job_id}), 201


@app.route("/api/jobs", methods=["GET"])
def list_jobs():
    hr_id = request.args.get("hr_id")
    status = request.args.get("status", "open")

    query = "SELECT * FROM jobs WHERE 1=1"
    params = []
    if hr_id:
        query += " AND hr_id = ?"
        params.append(hr_id)
    if status and status != "all":
        query += " AND status = ?"
        params.append(status)
    query += " ORDER BY created_at DESC"

    with db_cursor() as cur:
        cur.execute(query, params)
        rows = [dict(r) for r in cur.fetchall()]

    for r in rows:
        r["required_skills"] = [s for s in r["required_skills"].split(",") if s]

    return jsonify({"success": True, "jobs": rows})


@app.route("/api/jobs/<int:job_id>", methods=["GET"])
def get_job(job_id):
    with db_cursor() as cur:
        cur.execute("SELECT * FROM jobs WHERE id = ?", (job_id,))
        row = cur.fetchone()
    if row is None:
        return error_response("Job not found", 404)
    job = dict(row)
    job["required_skills"] = [s for s in job["required_skills"].split(",") if s]
    return jsonify({"success": True, "job": job})


@app.route("/api/jobs/<int:job_id>/status", methods=["PUT"])
def update_job_status(job_id):
    data = request.get_json(force=True)
    new_status = data.get("status")
    if new_status not in ("open", "closed"):
        return error_response("Invalid status")

    with db_cursor(commit=True) as cur:
        cur.execute("UPDATE jobs SET status = ? WHERE id = ?", (new_status, job_id))

    return jsonify({"success": True})


# ---------------------------------------------------------------------
# RESUMES (Candidate side)
# ---------------------------------------------------------------------
@app.route("/api/resumes/upload", methods=["POST"])
def upload_resume():
    if "file" not in request.files:
        return error_response("No file part in request")

    file = request.files["file"]
    candidate_id = request.form.get("candidate_id")

    if not candidate_id:
        return error_response("candidate_id is required")
    if file.filename == "":
        return error_response("No file selected")
    if not allowed_file(file.filename):
        return error_response(f"File type not allowed. Use: {ALLOWED_EXTENSIONS}")

    filename = secure_filename(file.filename)
    unique_name = f"{candidate_id}_{now_str().replace(' ', '_').replace(':', '-')}_{filename}"
    file_path = os.path.join(app.config["UPLOAD_FOLDER"], unique_name)
    file.save(file_path)

    try:
        parsed = parse_resume(file_path)
    except Exception as e:
        os.remove(file_path)
        return error_response(f"Failed to parse resume: {e}")

    with db_cursor(commit=True) as cur:
        cur.execute(
            """INSERT INTO resumes (candidate_id, file_path, original_filename,
                                     raw_text, parsed_name, parsed_email, parsed_phone,
                                     parsed_skills, parsed_experience_years,
                                     parsed_education, uploaded_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                candidate_id,
                file_path,
                filename,
                parsed["raw_text"],
                parsed["name"],
                parsed["email"],
                parsed["phone"],
                ",".join(parsed["skills"]),
                parsed["experience_years"],
                parsed["education"],
                now_str(),
            ),
        )
        resume_id = cur.lastrowid

    return jsonify({
        "success": True,
        "resume_id": resume_id,
        "parsed": {
            "name": parsed["name"],
            "email": parsed["email"],
            "phone": parsed["phone"],
            "skills": parsed["skills"],
            "experience_years": parsed["experience_years"],
            "education": parsed["education"],
        },
    }), 201


@app.route("/api/resumes", methods=["GET"])
def list_resumes():
    candidate_id = request.args.get("candidate_id")
    if not candidate_id:
        return error_response("candidate_id is required")

    with db_cursor() as cur:
        cur.execute(
            "SELECT * FROM resumes WHERE candidate_id = ? ORDER BY uploaded_at DESC",
            (candidate_id,),
        )
        rows = [dict(r) for r in cur.fetchall()]

    for r in rows:
        r["parsed_skills"] = [s for s in (r["parsed_skills"] or "").split(",") if s]

    return jsonify({"success": True, "resumes": rows})


# ---------------------------------------------------------------------
# APPLICATIONS
# ---------------------------------------------------------------------
@app.route("/api/applications", methods=["POST"])
def apply_to_job():
    data = request.get_json(force=True)
    required = ["job_id", "candidate_id", "resume_id"]
    if not all(k in data for k in required):
        return error_response(f"Missing fields. Required: {required}")

    # Fetch job + resume to compute match score immediately
    with db_cursor() as cur:
        cur.execute("SELECT * FROM jobs WHERE id = ?", (data["job_id"],))
        job_row = cur.fetchone()
        cur.execute("SELECT * FROM resumes WHERE id = ?", (data["resume_id"],))
        resume_row = cur.fetchone()

    if job_row is None or resume_row is None:
        return error_response("Job or resume not found", 404)

    job = dict(job_row)
    resume = dict(resume_row)

    score_result = matcher.score(
        resume_text=resume["raw_text"] or "",
        candidate_skills=[s for s in (resume["parsed_skills"] or "").split(",") if s],
        candidate_experience=resume["parsed_experience_years"] or 0,
        job_description=job["description"],
        required_skills=[s for s in job["required_skills"].split(",") if s],
        min_experience=job["min_experience"] or 0,
    )

    try:
        with db_cursor(commit=True) as cur:
            cur.execute(
                """INSERT INTO applications (job_id, candidate_id, resume_id,
                                              match_score, applied_at)
                   VALUES (?, ?, ?, ?, ?)""",
                (
                    data["job_id"],
                    data["candidate_id"],
                    data["resume_id"],
                    score_result["overall_score"],
                    now_str(),
                ),
            )
            app_id = cur.lastrowid
    except Exception as e:
        if "UNIQUE constraint" in str(e):
            return error_response("You have already applied to this job.")
        return error_response(str(e))

    return jsonify({
        "success": True,
        "application_id": app_id,
        "match_score": score_result,
    }), 201


@app.route("/api/applications", methods=["GET"])
def list_applications():
    job_id = request.args.get("job_id")
    candidate_id = request.args.get("candidate_id")

    query = """
        SELECT a.*, j.title as job_title, j.location as job_location,
               u.full_name as candidate_name, u.email as candidate_email,
               r.parsed_skills, r.parsed_experience_years, r.original_filename
        FROM applications a
        JOIN jobs j ON a.job_id = j.id
        JOIN users u ON a.candidate_id = u.id
        JOIN resumes r ON a.resume_id = r.id
        WHERE 1=1
    """
    params = []
    if job_id:
        query += " AND a.job_id = ?"
        params.append(job_id)
    if candidate_id:
        query += " AND a.candidate_id = ?"
        params.append(candidate_id)
    query += " ORDER BY a.match_score DESC"

    with db_cursor() as cur:
        cur.execute(query, params)
        rows = [dict(r) for r in cur.fetchall()]

    for r in rows:
        r["parsed_skills"] = [s for s in (r["parsed_skills"] or "").split(",") if s]

    return jsonify({"success": True, "applications": rows})


@app.route("/api/applications/<int:app_id>/status", methods=["PUT"])
def update_application_status(app_id):
    data = request.get_json(force=True)
    new_status = data.get("status")
    if new_status not in ("applied", "shortlisted", "rejected", "hired"):
        return error_response("Invalid status")

    with db_cursor(commit=True) as cur:
        cur.execute(
            "UPDATE applications SET status = ? WHERE id = ?", (new_status, app_id)
        )

    return jsonify({"success": True})


@app.route("/api/jobs/<int:job_id>/ranked-candidates", methods=["GET"])
def ranked_candidates(job_id):
    """ML-powered endpoint: returns all applicants for a job, ranked by match score."""
    with db_cursor() as cur:
        cur.execute("SELECT * FROM jobs WHERE id = ?", (job_id,))
        job_row = cur.fetchone()

    if job_row is None:
        return error_response("Job not found", 404)

    job = dict(job_row)
    job["required_skills"] = [s for s in job["required_skills"].split(",") if s]

    with db_cursor() as cur:
        cur.execute(
            """
            SELECT a.id as application_id, a.status, a.applied_at,
                   u.id as candidate_id, u.full_name, u.email,
                   r.id as resume_id, r.raw_text, r.parsed_skills,
                   r.parsed_experience_years, r.original_filename
            FROM applications a
            JOIN users u ON a.candidate_id = u.id
            JOIN resumes r ON a.resume_id = r.id
            WHERE a.job_id = ?
            """,
            (job_id,),
        )
        rows = [dict(r) for r in cur.fetchall()]

    candidates = []
    for r in rows:
        candidates.append({
            "application_id": r["application_id"],
            "candidate_id": r["candidate_id"],
            "name": r["full_name"],
            "email": r["email"],
            "status": r["status"],
            "applied_at": r["applied_at"],
            "resume_filename": r["original_filename"],
            "raw_text": r["raw_text"] or "",
            "skills": [s for s in (r["parsed_skills"] or "").split(",") if s],
            "experience_years": r["parsed_experience_years"] or 0,
        })

    ranked = matcher.rank_candidates(candidates, job)
    for r in ranked:
        r.pop("raw_text", None)  # don't ship full resume text back over the wire

    return jsonify({"success": True, "job": job, "ranked_candidates": ranked})


# ---------------------------------------------------------------------
# MESSAGES (HR <-> Candidate interaction)
# ---------------------------------------------------------------------
@app.route("/api/messages", methods=["POST"])
def send_message():
    data = request.get_json(force=True)
    required = ["application_id", "sender_id", "message"]
    if not all(k in data for k in required):
        return error_response(f"Missing fields. Required: {required}")

    with db_cursor(commit=True) as cur:
        cur.execute(
            """INSERT INTO messages (application_id, sender_id, message, sent_at)
               VALUES (?, ?, ?, ?)""",
            (data["application_id"], data["sender_id"], data["message"], now_str()),
        )

    return jsonify({"success": True}), 201


@app.route("/api/messages", methods=["GET"])
def get_messages():
    application_id = request.args.get("application_id")
    if not application_id:
        return error_response("application_id is required")

    with db_cursor() as cur:
        cur.execute(
            """SELECT m.*, u.full_name as sender_name, u.role as sender_role
               FROM messages m
               JOIN users u ON m.sender_id = u.id
               WHERE m.application_id = ?
               ORDER BY m.sent_at ASC""",
            (application_id,),
        )
        rows = [dict(r) for r in cur.fetchall()]

    return jsonify({"success": True, "messages": rows})


# ---------------------------------------------------------------------
# DASHBOARD STATS (for matplotlib visualizations in Streamlit)
# ---------------------------------------------------------------------
@app.route("/api/stats/hr/<int:hr_id>", methods=["GET"])
def hr_stats(hr_id):
    with db_cursor() as cur:
        cur.execute("SELECT COUNT(*) as c FROM jobs WHERE hr_id = ?", (hr_id,))
        total_jobs = cur.fetchone()["c"]

        cur.execute(
            "SELECT COUNT(*) as c FROM jobs WHERE hr_id = ? AND status='open'", (hr_id,)
        )
        open_jobs = cur.fetchone()["c"]

        cur.execute(
            """SELECT COUNT(*) as c FROM applications a
               JOIN jobs j ON a.job_id = j.id WHERE j.hr_id = ?""",
            (hr_id,),
        )
        total_applications = cur.fetchone()["c"]

        cur.execute(
            """SELECT j.title, COUNT(a.id) as applicant_count
               FROM jobs j LEFT JOIN applications a ON j.id = a.job_id
               WHERE j.hr_id = ? GROUP BY j.id ORDER BY applicant_count DESC""",
            (hr_id,),
        )
        applicants_per_job = [dict(r) for r in cur.fetchall()]

        cur.execute(
            """SELECT a.status, COUNT(*) as c FROM applications a
               JOIN jobs j ON a.job_id = j.id WHERE j.hr_id = ?
               GROUP BY a.status""",
            (hr_id,),
        )
        status_breakdown = [dict(r) for r in cur.fetchall()]

    return jsonify({
        "success": True,
        "total_jobs": total_jobs,
        "open_jobs": open_jobs,
        "total_applications": total_applications,
        "applicants_per_job": applicants_per_job,
        "status_breakdown": status_breakdown,
    })


@app.route("/api/stats/candidate/<int:candidate_id>", methods=["GET"])
def candidate_stats(candidate_id):
    with db_cursor() as cur:
        cur.execute(
            "SELECT COUNT(*) as c FROM resumes WHERE candidate_id = ?", (candidate_id,)
        )
        total_resumes = cur.fetchone()["c"]

        cur.execute(
            "SELECT COUNT(*) as c FROM applications WHERE candidate_id = ?",
            (candidate_id,),
        )
        total_applications = cur.fetchone()["c"]

        cur.execute(
            """SELECT j.title, a.match_score, a.status, a.applied_at
               FROM applications a JOIN jobs j ON a.job_id = j.id
               WHERE a.candidate_id = ? ORDER BY a.applied_at DESC""",
            (candidate_id,),
        )
        applications = [dict(r) for r in cur.fetchall()]

    return jsonify({
        "success": True,
        "total_resumes": total_resumes,
        "total_applications": total_applications,
        "applications": applications,
    })


if __name__ == "__main__":
    debug_mode = os.environ.get("FLASK_DEBUG", "0") == "1"
    app.run(host="0.0.0.0", port=5000, debug=debug_mode)
