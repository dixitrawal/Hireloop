import streamlit as st
import matplotlib.pyplot as plt
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils import api_client

st.set_page_config(page_title="My Applications | HireLoop", page_icon="📨", layout="wide")

if st.session_state.get("user") is None:
    st.warning("Please log in first.")
    st.stop()

user = st.session_state.user
if user["role"] != "candidate":
    st.error("This page is only available to Candidate accounts.")
    st.stop()

st.title("📨 My Applications")

ok, data = api_client.list_applications(candidate_id=user["id"])

if not ok or not data["applications"]:
    st.info("You haven't applied to any jobs yet. Head to **Browse Jobs** to get started.")
    st.stop()

applications = data["applications"]

status_emoji = {"applied": "⚪", "shortlisted": "🟡", "rejected": "🔴", "hired": "🟢"}

# ---------------------------------------------------------------------
# Summary chart: match scores across applications
# ---------------------------------------------------------------------
if len(applications) > 1:
    st.subheader("Your Match Scores at a Glance")
    titles = [a["job_title"] for a in applications]
    scores = [a["match_score"] or 0 for a in applications]

    fig, ax = plt.subplots(figsize=(9, max(2.5, len(titles) * 0.4)))
    ax.barh(titles, scores, color="#2B4C7E")
    ax.set_xlabel("Match Score (%)")
    ax.set_xlim(0, 100)
    ax.invert_yaxis()
    fig.tight_layout()
    st.pyplot(fig)
    plt.close(fig)
    st.divider()

st.subheader(f"📋 {len(applications)} Application(s)")

for a in applications:
    with st.container(border=True):
        col1, col2 = st.columns([3, 1])
        with col1:
            st.markdown(f"### {a['job_title']}")
            st.caption(f"📍 {a.get('job_location') or 'Location not specified'} · Applied on {a['applied_at']}")
        with col2:
            emoji = status_emoji.get(a["status"], "⚪")
            st.markdown(f"### {emoji} {a['status'].title()}")

        if a["match_score"] is not None:
            st.progress(min(a["match_score"] / 100, 1.0), text=f"Match Score: {a['match_score']:.1f}%")

        with st.expander("💬 Messages from HR"):
            ok_msg, msg_data = api_client.get_messages(a["id"])
            if ok_msg and msg_data["messages"]:
                for m in msg_data["messages"]:
                    sender_label = "🎓 You" if m["sender_role"] == "candidate" else f"🏢 {m['sender_name']}"
                    st.markdown(f"**{sender_label}** _{m['sent_at']}_")
                    st.write(m["message"])
                    st.markdown("---")
            else:
                st.caption("No messages yet.")

            reply = st.text_area("Reply", key=f"reply_{a['id']}", height=80)
            if st.button("Send Reply", key=f"send_reply_{a['id']}"):
                if reply.strip():
                    api_client.send_message(a["id"], user["id"], reply.strip())
                    st.success("Reply sent!")
                    st.rerun()
                else:
                    st.warning("Message cannot be empty.")
