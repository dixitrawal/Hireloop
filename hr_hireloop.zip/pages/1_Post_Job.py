import streamlit as st
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils import api_client

st.set_page_config(page_title="Post a Job | HireLoop", page_icon="📝", layout="wide")

if st.session_state.get("user") is None:
    st.warning("Please log in first.")
    st.stop()

user = st.session_state.user
if user["role"] != "hr":
    st.error("This page is only available to HR accounts.")
    st.stop()

st.title("📝 Post a New Job")
st.caption("Fill in the role details. Candidates who apply will be automatically scored against these requirements using our ML matching engine.")

with st.form("job_form", clear_on_submit=True):
    title = st.text_input("Job Title *", placeholder="e.g. Senior Python Developer")

    description = st.text_area(
        "Job Description *",
        placeholder="Describe the role, responsibilities, and what you're looking for...",
        height=180,
    )

    col1, col2 = st.columns(2)
    with col1:
        skills_raw = st.text_input(
            "Required Skills * (comma-separated)",
            placeholder="python, flask, machine learning, sql",
        )
    with col2:
        min_experience = st.number_input(
            "Minimum Experience (years)", min_value=0.0, max_value=30.0, value=0.0, step=0.5
        )

    location = st.text_input("Location", placeholder="e.g. Bangalore, India / Remote")

    submitted = st.form_submit_button("🚀 Post Job", type="primary", use_container_width=True)

    if submitted:
        skills_list = [s.strip() for s in skills_raw.split(",") if s.strip()]

        if not title or not description or not skills_list:
            st.error("Please fill in the Job Title, Description, and at least one required skill.")
        else:
            success, result = api_client.create_job(
                hr_id=user["id"],
                title=title,
                description=description,
                required_skills=skills_list,
                min_experience=min_experience,
                location=location,
            )
            if success:
                st.success(f"✅ Job posted successfully! (Job ID: {result['job_id']})")
                st.balloons()
            else:
                st.error(result.get("message", "Failed to post job."))

st.divider()
st.subheader("Your Posted Jobs")

ok, data = api_client.list_jobs(hr_id=user["id"], status="all")
if ok and data["jobs"]:
    for job in data["jobs"]:
        with st.container(border=True):
            c1, c2 = st.columns([4, 1])
            with c1:
                st.markdown(f"**{job['title']}** · {job.get('location') or 'Location not specified'}")
                st.caption(f"Skills: {', '.join(job['required_skills'])} · Min experience: {job['min_experience']} yrs")
            with c2:
                status_color = "🟢" if job["status"] == "open" else "🔴"
                st.markdown(f"{status_color} **{job['status'].upper()}**")
                new_status = "closed" if job["status"] == "open" else "open"
                if st.button(
                    f"Mark as {new_status.title()}",
                    key=f"toggle_{job['id']}",
                    use_container_width=True,
                ):
                    api_client.update_job_status(job["id"], new_status)
                    st.rerun()
else:
    st.info("You haven't posted any jobs yet. Use the form above to create your first listing.")
