import streamlit as st
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils import api_client

st.set_page_config(page_title="Browse Jobs | HireLoop", page_icon="🔍", layout="wide")

if st.session_state.get("user") is None:
    st.warning("Please log in first.")
    st.stop()

user = st.session_state.user
if user["role"] != "candidate":
    st.error("This page is only available to Candidate accounts.")
    st.stop()

st.title("🔍 Browse Open Jobs")

# Fetch candidate's resumes for the apply dropdown
ok_resumes, resume_data = api_client.list_resumes(user["id"])
resumes = resume_data["resumes"] if ok_resumes else []

if not resumes:
    st.warning(
        "⚠️ You haven't uploaded a resume yet. "
        "Please go to **My Resumes** to upload one before applying to jobs."
    )

# Fetch already-applied job IDs to avoid duplicate-apply UI confusion
ok_apps, apps_data = api_client.list_applications(candidate_id=user["id"])
applied_job_ids = {a["job_id"] for a in apps_data["applications"]} if ok_apps else set()

search_query = st.text_input("🔎 Search jobs by title or skill", placeholder="e.g. python, data analyst")

ok, data = api_client.list_jobs(status="open")

if not ok or not data["jobs"]:
    st.info("No open jobs available right now. Check back later!")
    st.stop()

jobs = data["jobs"]
if search_query:
    q = search_query.lower()
    jobs = [
        j for j in jobs
        if q in j["title"].lower() or any(q in s.lower() for s in j["required_skills"])
    ]

st.caption(f"Showing {len(jobs)} open position(s)")
st.divider()

resume_options = {f"{r['original_filename']} (uploaded {r['uploaded_at']})": r["id"] for r in resumes}

for job in jobs:
    with st.container(border=True):
        st.markdown(f"### {job['title']}")
        st.caption(f"📍 {job.get('location') or 'Location not specified'} · 💼 Min {job['min_experience']} yrs experience")
        st.write(job["description"])
        st.markdown("**Required skills:** " + ", ".join(f"`{s}`" for s in job["required_skills"]))

        already_applied = job["id"] in applied_job_ids

        if already_applied:
            st.success("✅ You've already applied to this job.")
        elif not resumes:
            st.button("Apply Now", disabled=True, key=f"apply_disabled_{job['id']}", help="Upload a resume first.")
        else:
            col1, col2 = st.columns([3, 1])
            with col1:
                selected_resume_label = st.selectbox(
                    "Select resume to apply with:",
                    list(resume_options.keys()),
                    key=f"resume_select_{job['id']}",
                    label_visibility="collapsed",
                )
            with col2:
                if st.button("Apply Now", key=f"apply_{job['id']}", type="primary", use_container_width=True):
                    resume_id = resume_options[selected_resume_label]
                    success, result = api_client.apply_to_job(job["id"], user["id"], resume_id)
                    if success:
                        score = result["match_score"]["overall_score"]
                        st.success(f"🎉 Application submitted! Your match score: **{score:.1f}%**")
                        st.rerun()
                    else:
                        st.error(result.get("message", "Application failed."))
