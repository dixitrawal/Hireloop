import streamlit as st
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils import api_client

st.set_page_config(page_title="HR Dashboard | HireLoop", page_icon="📊", layout="wide")

if st.session_state.get("user") is None:
    st.warning("Please log in first.")
    st.stop()

user = st.session_state.user
if user["role"] != "hr":
    st.error("This page is only available to HR accounts.")
    st.stop()

st.title("📊 HR Analytics Dashboard")
st.caption(f"Recruitment overview for {user.get('company_name', 'your company')}")

ok, stats = api_client.get_hr_stats(user["id"])
if not ok:
    st.error("Failed to load dashboard stats.")
    st.stop()

c1, c2, c3 = st.columns(3)
c1.metric("Total Jobs Posted", stats["total_jobs"])
c2.metric("Currently Open", stats["open_jobs"])
c3.metric("Total Applications Received", stats["total_applications"])

st.divider()

if stats["total_applications"] == 0:
    st.info("No applications yet. Once candidates start applying, your analytics will appear here.")
    st.stop()

colA, colB = st.columns(2)

# ---------------------------------------------------------------------
# Chart 1: Applicants per job (bar chart)
# ---------------------------------------------------------------------
with colA:
    st.subheader("Applicants per Job Posting")
    df_jobs = pd.DataFrame(stats["applicants_per_job"])
    if not df_jobs.empty:
        fig, ax = plt.subplots(figsize=(6, 4))
        ax.bar(df_jobs["title"], df_jobs["applicant_count"], color="#2B4C7E")
        ax.set_ylabel("Number of Applicants")
        ax.set_xticklabels(df_jobs["title"], rotation=30, ha="right")
        ax.yaxis.set_major_locator(plt.MaxNLocator(integer=True))
        fig.tight_layout()
        st.pyplot(fig)
        plt.close(fig)
    else:
        st.info("No job data available.")

# ---------------------------------------------------------------------
# Chart 2: Application status breakdown (pie chart)
# ---------------------------------------------------------------------
with colB:
    st.subheader("Application Status Breakdown")
    df_status = pd.DataFrame(stats["status_breakdown"])
    if not df_status.empty:
        status_colors = {
            "applied": "#94A3B8",
            "shortlisted": "#F5B942",
            "rejected": "#DC5C4C",
            "hired": "#4CAF7D",
        }
        colors = [status_colors.get(s, "#999999") for s in df_status["status"]]
        fig, ax = plt.subplots(figsize=(6, 4))
        ax.pie(
            df_status["c"],
            labels=df_status["status"].str.title(),
            autopct="%1.0f%%",
            colors=colors,
            startangle=90,
        )
        ax.axis("equal")
        fig.tight_layout()
        st.pyplot(fig)
        plt.close(fig)
    else:
        st.info("No application status data available.")

st.divider()

# ---------------------------------------------------------------------
# Table: raw data for reference (pandas + numpy summary stats)
# ---------------------------------------------------------------------
st.subheader("Applicants-per-Job Data")
if not df_jobs.empty:
    df_display = df_jobs.rename(columns={"title": "Job Title", "applicant_count": "Applicants"})
    st.dataframe(df_display, use_container_width=True, hide_index=True)

    avg_applicants = np.mean(df_jobs["applicant_count"])
    max_applicants = np.max(df_jobs["applicant_count"])
    st.caption(
        f"📈 Average of **{avg_applicants:.1f}** applicants per job posting · "
        f"Most popular listing received **{max_applicants}** application(s)."
    )
