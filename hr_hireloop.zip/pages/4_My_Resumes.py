import streamlit as st
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils import api_client

st.set_page_config(page_title="My Resumes | HireLoop", page_icon="📄", layout="wide")

if st.session_state.get("user") is None:
    st.warning("Please log in first.")
    st.stop()

user = st.session_state.user
if user["role"] != "candidate":
    st.error("This page is only available to Candidate accounts.")
    st.stop()

st.title("📄 My Resumes")
st.caption("Upload your resume in PDF, DOCX, or TXT format. Our parser will automatically extract your skills, experience, and contact details.")

uploaded_file = st.file_uploader(
    "Upload a resume",
    type=["pdf", "docx", "doc", "txt"],
    help="Max file size: 10 MB",
)

if uploaded_file is not None:
    if st.button("📤 Upload & Parse Resume", type="primary"):
        with st.spinner("Parsing your resume..."):
            success, result = api_client.upload_resume(
                candidate_id=user["id"],
                file_bytes=uploaded_file.getvalue(),
                filename=uploaded_file.name,
            )
        if success:
            st.success("✅ Resume uploaded and parsed successfully!")
            parsed = result["parsed"]

            c1, c2 = st.columns(2)
            with c1:
                st.markdown(f"**Name detected:** {parsed['name']}")
                st.markdown(f"**Email detected:** {parsed['email']}")
                st.markdown(f"**Phone detected:** {parsed['phone']}")
            with c2:
                st.markdown(f"**Experience:** {parsed['experience_years']} years")
                st.markdown(f"**Education:** {parsed['education']}")

            if parsed["skills"]:
                st.markdown("**Skills extracted:**")
                st.write(", ".join(f"`{s}`" for s in parsed["skills"]))
            else:
                st.warning(
                    "No recognized skills were found. Consider adding a clear "
                    "'Skills' section to your resume for better job matching."
                )
        else:
            st.error(result.get("message", "Upload failed."))

st.divider()
st.subheader("📚 Uploaded Resumes")

ok, data = api_client.list_resumes(user["id"])
if ok and data["resumes"]:
    for r in data["resumes"]:
        with st.container(border=True):
            st.markdown(f"**{r['original_filename']}** · uploaded {r['uploaded_at']}")
            c1, c2, c3 = st.columns(3)
            c1.caption(f"👤 {r['parsed_name']}")
            c2.caption(f"💼 {r['parsed_experience_years']} yrs experience")
            c3.caption(f"🎓 {r['parsed_education']}")
            if r["parsed_skills"]:
                st.caption("Skills: " + ", ".join(r["parsed_skills"]))
else:
    st.info("You haven't uploaded any resumes yet. Use the uploader above to get started.")
