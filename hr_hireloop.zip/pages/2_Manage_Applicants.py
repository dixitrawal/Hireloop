import streamlit as st
import matplotlib.pyplot as plt
import numpy as np
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils import api_client

st.set_page_config(page_title="Manage Applicants | HireLoop", page_icon="📋", layout="wide")

if st.session_state.get("user") is None:
    st.warning("Please log in first.")
    st.stop()

user = st.session_state.user
if user["role"] != "hr":
    st.error("This page is only available to HR accounts.")
    st.stop()

st.title("📋 Manage Applicants")
st.caption("View candidates ranked by ML-computed match score for each of your job postings.")

ok, data = api_client.list_jobs(hr_id=user["id"], status="all")
if not ok or not data["jobs"]:
    st.info("You haven't posted any jobs yet. Head to **Post a Job** to create one.")
    st.stop()

job_options = {f"{j['title']} (ID {j['id']}, {j['status']})": j["id"] for j in data["jobs"]}
selected_label = st.selectbox("Select a job to view applicants:", list(job_options.keys()))
selected_job_id = job_options[selected_label]

ok, ranked_data = api_client.get_ranked_candidates(selected_job_id)

if not ok:
    st.error("Failed to load applicants.")
    st.stop()

job = ranked_data["job"]
candidates = ranked_data["ranked_candidates"]

with st.expander("📄 Job Details", expanded=False):
    st.write(f"**Description:** {job['description']}")
    st.write(f"**Required Skills:** {', '.join(job['required_skills'])}")
    st.write(f"**Minimum Experience:** {job['min_experience']} years")
    st.write(f"**Location:** {job.get('location') or 'Not specified'}")

st.divider()

if not candidates:
    st.info("No applicants yet for this job.")
    st.stop()

st.subheader(f"👥 {len(candidates)} Applicant(s) — Ranked by Match Score")

# ---------------------------------------------------------------------
# Matplotlib visualization: match score bar chart
# ---------------------------------------------------------------------
names = [c["name"] for c in candidates]
scores = [c["overall_score"] for c in candidates]

fig, ax = plt.subplots(figsize=(9, max(2.5, len(names) * 0.5)))
colors = plt.cm.RdYlGn(np.array(scores) / 100)
bars = ax.barh(names, scores, color=colors)
ax.set_xlabel("Match Score (%)")
ax.set_xlim(0, 100)
ax.set_title(f"Candidate Match Scores — {job['title']}")
ax.invert_yaxis()  # highest score on top
for bar, score in zip(bars, scores):
    ax.text(bar.get_width() + 1, bar.get_y() + bar.get_height() / 2, f"{score:.1f}%", va="center", fontsize=9)
fig.tight_layout()
st.pyplot(fig)
plt.close(fig)

st.divider()

# ---------------------------------------------------------------------
# Candidate cards with status controls & messaging
# ---------------------------------------------------------------------
status_options = ["applied", "shortlisted", "rejected", "hired"]
status_emoji = {"applied": "⚪", "shortlisted": "🟡", "rejected": "🔴", "hired": "🟢"}

for c in candidates:
    with st.container(border=True):
        col1, col2, col3 = st.columns([3, 2, 1.3])

        with col1:
            st.markdown(f"### {c['name']} — {c['overall_score']:.1f}% match")
            st.caption(f"📧 {c['email']} · 📎 {c['resume_filename']} · 💼 {c['experience_years']} yrs experience")
            if c["matched_skills"]:
                st.markdown("✅ **Matched:** " + ", ".join(c["matched_skills"]))
            if c["missing_skills"]:
                st.markdown("⚠️ **Missing:** " + ", ".join(c["missing_skills"]))

        with col2:
            st.metric("Text Similarity", f"{c['text_similarity']:.1f}%")
            st.metric("Skill Match", f"{c['skill_match']:.1f}%")
            st.metric("Experience Fit", f"{c['experience_fit']:.1f}%")

        with col3:
            current_status = c["status"]
            new_status = st.selectbox(
                "Status",
                status_options,
                index=status_options.index(current_status),
                key=f"status_{c['application_id']}",
                format_func=lambda s: f"{status_emoji[s]} {s.title()}",
            )
            if new_status != current_status:
                if st.button("Update", key=f"update_{c['application_id']}", use_container_width=True):
                    api_client.update_application_status(c["application_id"], new_status)
                    st.success("Status updated!")
                    st.rerun()

        with st.expander("💬 Message this candidate"):
            ok_msg, msg_data = api_client.get_messages(c["application_id"])
            if ok_msg and msg_data["messages"]:
                for m in msg_data["messages"]:
                    align = "🏢 You" if m["sender_role"] == "hr" else f"🎓 {m['sender_name']}"
                    st.markdown(f"**{align}** _{m['sent_at']}_")
                    st.write(m["message"])
                    st.markdown("---")
            new_msg = st.text_area("Your message", key=f"msg_{c['application_id']}", height=80)
            if st.button("Send", key=f"send_{c['application_id']}"):
                if new_msg.strip():
                    api_client.send_message(c["application_id"], user["id"], new_msg.strip())
                    st.success("Message sent!")
                    st.rerun()
                else:
                    st.warning("Message cannot be empty.")
