"""
HR-Candidate Interaction Platform
===================================
Main Streamlit entry point. Handles session-state authentication and
routes to role-specific dashboards (HR vs Candidate).

Run with: streamlit run streamlit_app.py
(Requires the Flask API server to be running: python app.py)
"""
import streamlit as st
import sys
import os

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from utils import api_client

st.set_page_config(
    page_title="HireLoop | HR & Candidate Platform",
    page_icon="🧭",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ---------------------------------------------------------------------
# Session state initialization
# ---------------------------------------------------------------------
if "user" not in st.session_state:
    st.session_state.user = None
if "auth_mode" not in st.session_state:
    st.session_state.auth_mode = "login"  # or "register"


def logout():
    st.session_state.user = None
    st.rerun()


# ---------------------------------------------------------------------
# API connectivity check
# ---------------------------------------------------------------------
if not api_client.is_api_up():
    st.error(
        "**Backend API is not reachable.** "
        "Please start the Flask server first by running `python app.py` "
        "in the project folder, then refresh this page."
    )
    st.stop()


# ---------------------------------------------------------------------
# AUTH SCREEN (shown when nobody is logged in)
# ---------------------------------------------------------------------
def render_auth_screen():
    st.markdown(
        "<h1 style='margin-bottom:0;'>🧭 HireLoop</h1>"
        "<p style='color:#5A6472; margin-top:4px;'>Where HR teams and candidates connect, powered by resume intelligence.</p>",
        unsafe_allow_html=True,
    )
    st.divider()

    left, right = st.columns([1, 1.2], gap="large")

    with left:
        tab_login, tab_register = st.tabs(["Log In", "Register"])

        with tab_login:
            st.subheader("Welcome back")
            with st.form("login_form"):
                email = st.text_input("Email", placeholder="you@example.com")
                password = st.text_input("Password", type="password")
                submitted = st.form_submit_button("Log In", use_container_width=True, type="primary")

                if submitted:
                    if not email or not password:
                        st.warning("Please enter both email and password.")
                    else:
                        success, result = api_client.login(email, password)
                        if success:
                            st.session_state.user = result["user"]
                            st.success("Logged in successfully!")
                            st.rerun()
                        else:
                            st.error(result.get("message", "Login failed."))

        with tab_register:
            st.subheader("Create your account")
            role = st.radio(
                "I am registering as a:",
                options=["candidate", "hr"],
                format_func=lambda r: "🎓 Candidate (job seeker)" if r == "candidate" else "🏢 HR / Recruiter",
                horizontal=True,
            )
            with st.form("register_form"):
                full_name = st.text_input("Full Name", placeholder="Jane Doe")
                reg_email = st.text_input("Email", placeholder="you@example.com", key="reg_email")
                company_name = None
                if role == "hr":
                    company_name = st.text_input("Company Name", placeholder="Acme Corp")
                reg_password = st.text_input("Password", type="password", key="reg_pw")
                confirm_password = st.text_input("Confirm Password", type="password")
                st.caption("Password must be at least 6 characters and include letters and numbers.")

                reg_submitted = st.form_submit_button("Create Account", use_container_width=True, type="primary")

                if reg_submitted:
                    if not full_name or not reg_email or not reg_password:
                        st.warning("Please fill in all required fields.")
                    elif reg_password != confirm_password:
                        st.error("Passwords do not match.")
                    elif role == "hr" and not company_name:
                        st.warning("Company name is required for HR accounts.")
                    else:
                        success, result = api_client.register(
                            full_name, reg_email, reg_password, role, company_name
                        )
                        if success:
                            st.success(result.get("message", "Registered!") + " Switch to the Log In tab.")
                        else:
                            st.error(result.get("message", "Registration failed."))

    with right:
        st.markdown("#### How HireLoop works")
        st.info(
            "**For Candidates:** Upload your resume, let our parser extract your "
            "skills automatically, then apply to open roles with one click."
        )
        st.info(
            "**For HR Teams:** Post a job once. Our ML matching engine "
            "(TF-IDF + cosine similarity via scikit-learn) ranks every "
            "applicant by fit — no manual resume screening needed."
        )
        st.caption(
            "Built with Streamlit · Flask · scikit-learn · pandas · NumPy · "
            "Matplotlib · pdfplumber/PyPDF2/python-docx for resume parsing."
        )


# ---------------------------------------------------------------------
# MAIN ROUTING
# ---------------------------------------------------------------------
if st.session_state.user is None:
    render_auth_screen()
else:
    user = st.session_state.user

    with st.sidebar:
        st.markdown(f"### 👋 {user['full_name']}")
        role_label = "🏢 HR / Recruiter" if user["role"] == "hr" else "🎓 Candidate"
        st.caption(role_label)
        if user.get("company_name"):
            st.caption(f"**{user['company_name']}**")
        st.divider()
        st.page_link("streamlit_app.py", label="🏠 Home")
        if user["role"] == "hr":
            st.page_link("pages/1_Post_Job.py", label="📝 Post a Job")
            st.page_link("pages/2_Manage_Applicants.py", label="📋 Manage Applicants")
            st.page_link("pages/3_HR_Dashboard.py", label="📊 Dashboard")
        else:
            st.page_link("pages/4_My_Resumes.py", label="📄 My Resumes")
            st.page_link("pages/5_Browse_Jobs.py", label="🔍 Browse Jobs")
            st.page_link("pages/6_My_Applications.py", label="📨 My Applications")
        st.divider()
        if st.button("Log Out", use_container_width=True):
            logout()

    st.markdown(
        f"<h1 style='margin-bottom:0;'>🧭 HireLoop</h1>"
        f"<p style='color:#5A6472;'>Welcome back, <b>{user['full_name']}</b>.</p>",
        unsafe_allow_html=True,
    )
    st.divider()

    if user["role"] == "hr":
        st.subheader("HR Home")
        c1, c2, c3 = st.columns(3)
        stats_ok, stats = api_client.get_hr_stats(user["id"])
        if stats_ok:
            c1.metric("Jobs Posted", stats["total_jobs"])
            c2.metric("Open Positions", stats["open_jobs"])
            c3.metric("Total Applications", stats["total_applications"])
        st.markdown(
            "Use the sidebar to **post a new job**, **review and rank applicants** "
            "using our ML matching engine, or view your **analytics dashboard**."
        )
    else:
        st.subheader("Candidate Home")
        c1, c2 = st.columns(2)
        stats_ok, stats = api_client.get_candidate_stats(user["id"])
        if stats_ok:
            c1.metric("Resumes Uploaded", stats["total_resumes"])
            c2.metric("Jobs Applied To", stats["total_applications"])
        st.markdown(
            "Use the sidebar to **upload a resume**, **browse open jobs**, "
            "or **track your applications** and messages from recruiters."
        )
