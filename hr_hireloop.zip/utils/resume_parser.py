"""
Resume Parser
-------------
Extracts structured information (name, email, phone, skills,
experience years, education) from PDF and DOCX resumes.

Uses:
  - pdfplumber (primary) / PyPDF2 (fallback) for PDF text extraction
  - python-docx for DOCX text extraction
  - regex-based entity extraction for contact info
  - a curated skills taxonomy for skill matching (no heavy NLP model
    required, keeps the app lightweight and fully offline)
"""
import re
import os

try:
    import pdfplumber
    HAS_PDFPLUMBER = True
except ImportError:
    HAS_PDFPLUMBER = False

import PyPDF2
import docx

# ---------------------------------------------------------------------
# Skills taxonomy — expand this list as needed for your domain
# ---------------------------------------------------------------------
SKILLS_DB = [
    # Programming languages
    "python", "java", "c++", "c#", "javascript", "typescript", "r", "go", "rust",
    "php", "ruby", "swift", "kotlin", "scala", "matlab", "sql", "html", "css",
    # Data / ML
    "machine learning", "deep learning", "data science", "artificial intelligence",
    "nlp", "natural language processing", "computer vision", "neural networks",
    "scikit-learn", "sklearn", "tensorflow", "pytorch", "keras", "pandas", "numpy",
    "matplotlib", "seaborn", "opencv", "data analysis", "data visualization",
    "statistics", "regression", "classification", "clustering", "xgboost",
    # Web / frameworks
    "flask", "django", "streamlit", "fastapi", "react", "angular", "vue",
    "node.js", "express", "spring", "spring boot", ".net", "rest api",
    "graphql", "microservices",
    # Databases
    "mysql", "postgresql", "mongodb", "sqlite", "oracle", "redis", "cassandra",
    "elasticsearch", "firebase",
    # Cloud / DevOps
    "aws", "azure", "gcp", "docker", "kubernetes", "jenkins", "ci/cd", "git",
    "github", "gitlab", "linux", "terraform", "ansible",
    # Business / soft
    "project management", "agile", "scrum", "communication", "leadership",
    "team management", "problem solving", "excel", "power bi", "tableau",
    "jira", "confluence",
]

EMAIL_PATTERN = re.compile(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}")
PHONE_PATTERN = re.compile(
    r"(\+\d{1,3}[-.\s]?)?\(?\d{2,5}\)?[-.\s]?\d{3,5}[-.\s]?\d{3,5}\b"
)
EXPERIENCE_PATTERN = re.compile(
    r"(\d+\.?\d*)\s*\+?\s*(?:years?|yrs?)\s*(?:of)?\s*(?:experience|exp)?",
    re.IGNORECASE,
)
EDUCATION_KEYWORDS = [
    "b.tech", "btech", "b.e.", "be", "bachelor", "m.tech", "mtech",
    "master", "msc", "m.sc", "bsc", "b.sc", "phd", "ph.d", "mba",
    "bca", "mca", "diploma", "12th", "10th", "high school",
]


def extract_text_from_pdf(file_path: str) -> str:
    text = ""
    if HAS_PDFPLUMBER:
        try:
            with pdfplumber.open(file_path) as pdf:
                for page in pdf.pages:
                    page_text = page.extract_text()
                    if page_text:
                        text += page_text + "\n"
            if text.strip():
                return text
        except Exception:
            pass  # fall through to PyPDF2

    # Fallback: PyPDF2
    try:
        with open(file_path, "rb") as f:
            reader = PyPDF2.PdfReader(f)
            for page in reader.pages:
                page_text = page.extract_text()
                if page_text:
                    text += page_text + "\n"
    except Exception as e:
        text += f"\n[Error extracting PDF text: {e}]"
    return text


def extract_text_from_docx(file_path: str) -> str:
    text = ""
    try:
        document = docx.Document(file_path)
        for para in document.paragraphs:
            text += para.text + "\n"
        for table in document.tables:
            for row in table.rows:
                for cell in row.cells:
                    text += cell.text + " "
                text += "\n"
    except Exception as e:
        text += f"\n[Error extracting DOCX text: {e}]"
    return text


def extract_text(file_path: str) -> str:
    ext = os.path.splitext(file_path)[1].lower()
    if ext == ".pdf":
        return extract_text_from_pdf(file_path)
    elif ext in (".docx", ".doc"):
        return extract_text_from_docx(file_path)
    elif ext == ".txt":
        with open(file_path, "r", errors="ignore") as f:
            return f.read()
    else:
        raise ValueError(f"Unsupported file type: {ext}")


def extract_name(text: str) -> str:
    """
    Heuristic: the name is usually the first non-empty line that
    doesn't look like a header word (resume, cv, curriculum vitae)
    and doesn't contain an email/phone/digit-heavy content.
    """
    lines = [l.strip() for l in text.split("\n") if l.strip()]
    skip_words = {"resume", "cv", "curriculum vitae", "bio-data", "profile"}
    for line in lines[:8]:
        lower = line.lower()
        if lower in skip_words:
            continue
        if EMAIL_PATTERN.search(line) or PHONE_PATTERN.search(line):
            continue
        if any(ch.isdigit() for ch in line):
            continue
        if len(line.split()) <= 5 and len(line) > 2:
            return line.title()
    return "Not Detected"


def extract_email(text: str) -> str:
    match = EMAIL_PATTERN.search(text)
    return match.group(0) if match else "Not Detected"


def extract_phone(text: str) -> str:
    match = PHONE_PATTERN.search(text)
    if match:
        cleaned = re.sub(r"\s+", " ", match.group(0)).strip()
        digit_count = sum(c.isdigit() for c in cleaned)
        if digit_count >= 7:
            return cleaned
    return "Not Detected"


def extract_skills(text: str) -> list:
    text_lower = text.lower()
    found_skills = []
    for skill in SKILLS_DB:
        pattern = r"(?<![a-zA-Z0-9])" + re.escape(skill) + r"(?![a-zA-Z0-9])"
        if re.search(pattern, text_lower):
            found_skills.append(skill)
    return sorted(set(found_skills))


def extract_experience_years(text: str) -> float:
    matches = EXPERIENCE_PATTERN.findall(text)
    if matches:
        try:
            years = [float(m) for m in matches if m]
            if years:
                return max(years)  # take the most emphasized/highest figure
        except ValueError:
            pass
    return 0.0


def extract_education(text: str) -> str:
    text_lower = text.lower()
    found = []
    for kw in EDUCATION_KEYWORDS:
        if kw in text_lower:
            found.append(kw.upper() if len(kw) <= 5 else kw.title())
    return ", ".join(sorted(set(found))) if found else "Not Detected"


def parse_resume(file_path: str) -> dict:
    """
    Main entry point. Returns a dictionary of parsed fields.
    """
    text = extract_text(file_path)
    return {
        "raw_text": text,
        "name": extract_name(text),
        "email": extract_email(text),
        "phone": extract_phone(text),
        "skills": extract_skills(text),
        "experience_years": extract_experience_years(text),
        "education": extract_education(text),
    }


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        result = parse_resume(sys.argv[1])
        for k, v in result.items():
            if k != "raw_text":
                print(f"{k}: {v}")
