"""
Authentication utilities: registration, login, and password hashing.
Uses werkzeug's security helpers (industry-standard salted hashing),
so plaintext passwords are never stored.
"""
import re
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash

import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from database.db_manager import db_cursor, now_str

EMAIL_REGEX = re.compile(r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$")


def is_valid_email(email: str) -> bool:
    return bool(EMAIL_REGEX.match(email.strip()))


def is_strong_password(password: str):
    """Return (is_valid, message)."""
    if len(password) < 6:
        return False, "Password must be at least 6 characters long."
    if not re.search(r"[A-Za-z]", password) or not re.search(r"[0-9]", password):
        return False, "Password must contain both letters and numbers."
    return True, ""


def register_user(full_name, email, password, role, company_name=None):
    """
    Register a new user (HR or Candidate).
    Returns (success: bool, message: str).
    """
    full_name = full_name.strip()
    email = email.strip().lower()

    if not full_name:
        return False, "Full name is required."
    if not is_valid_email(email):
        return False, "Please enter a valid email address."
    valid_pw, pw_msg = is_strong_password(password)
    if not valid_pw:
        return False, pw_msg
    if role not in ("hr", "candidate"):
        return False, "Invalid role selected."
    if role == "hr" and not (company_name and company_name.strip()):
        return False, "Company name is required for HR accounts."

    password_hash = generate_password_hash(password)

    try:
        with db_cursor(commit=True) as cur:
            cur.execute(
                """INSERT INTO users (full_name, email, password_hash, role, company_name, created_at)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (full_name, email, password_hash, role, company_name, now_str()),
            )
        return True, "Registration successful! Please log in."
    except sqlite3.IntegrityError:
        return False, "An account with this email already exists."
    except Exception as e:
        return False, f"Registration failed: {e}"


def login_user(email, password):
    """
    Validate login credentials.
    Returns (success: bool, user_dict_or_message).
    """
    email = email.strip().lower()
    with db_cursor() as cur:
        cur.execute("SELECT * FROM users WHERE email = ?", (email,))
        row = cur.fetchone()

    if row is None:
        return False, "No account found with this email."

    if not check_password_hash(row["password_hash"], password):
        return False, "Incorrect password. Please try again."

    user = dict(row)
    user.pop("password_hash", None)
    return True, user


def get_user_by_id(user_id):
    with db_cursor() as cur:
        cur.execute("SELECT * FROM users WHERE id = ?", (user_id,))
        row = cur.fetchone()
    if row is None:
        return None
    user = dict(row)
    user.pop("password_hash", None)
    return user
