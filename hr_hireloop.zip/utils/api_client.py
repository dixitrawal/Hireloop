"""
Thin HTTP client wrapping the Flask REST API for use from Streamlit.
Centralizing requests here keeps the Streamlit page code focused on UI logic.
"""
import requests

API_BASE = "http://localhost:5000/api"
TIMEOUT = 15


def _handle(resp):
    try:
        data = resp.json()
    except ValueError:
        return False, {"message": "Server returned an unexpected response."}
    return resp.ok, data


def register(full_name, email, password, role, company_name=None):
    payload = {
        "full_name": full_name,
        "email": email,
        "password": password,
        "role": role,
    }
    if company_name:
        payload["company_name"] = company_name
    resp = requests.post(f"{API_BASE}/register", json=payload, timeout=TIMEOUT)
    return _handle(resp)


def login(email, password):
    resp = requests.post(
        f"{API_BASE}/login", json={"email": email, "password": password}, timeout=TIMEOUT
    )
    return _handle(resp)


def create_job(hr_id, title, description, required_skills, min_experience, location):
    payload = {
        "hr_id": hr_id,
        "title": title,
        "description": description,
        "required_skills": required_skills,
        "min_experience": min_experience,
        "location": location,
    }
    resp = requests.post(f"{API_BASE}/jobs", json=payload, timeout=TIMEOUT)
    return _handle(resp)


def list_jobs(hr_id=None, status="open"):
    params = {"status": status}
    if hr_id:
        params["hr_id"] = hr_id
    resp = requests.get(f"{API_BASE}/jobs", params=params, timeout=TIMEOUT)
    return _handle(resp)


def get_job(job_id):
    resp = requests.get(f"{API_BASE}/jobs/{job_id}", timeout=TIMEOUT)
    return _handle(resp)


def update_job_status(job_id, status):
    resp = requests.put(f"{API_BASE}/jobs/{job_id}/status", json={"status": status}, timeout=TIMEOUT)
    return _handle(resp)


def upload_resume(candidate_id, file_bytes, filename):
    files = {"file": (filename, file_bytes)}
    data = {"candidate_id": candidate_id}
    resp = requests.post(f"{API_BASE}/resumes/upload", files=files, data=data, timeout=TIMEOUT)
    return _handle(resp)


def list_resumes(candidate_id):
    resp = requests.get(f"{API_BASE}/resumes", params={"candidate_id": candidate_id}, timeout=TIMEOUT)
    return _handle(resp)


def apply_to_job(job_id, candidate_id, resume_id):
    payload = {"job_id": job_id, "candidate_id": candidate_id, "resume_id": resume_id}
    resp = requests.post(f"{API_BASE}/applications", json=payload, timeout=TIMEOUT)
    return _handle(resp)


def list_applications(job_id=None, candidate_id=None):
    params = {}
    if job_id:
        params["job_id"] = job_id
    if candidate_id:
        params["candidate_id"] = candidate_id
    resp = requests.get(f"{API_BASE}/applications", params=params, timeout=TIMEOUT)
    return _handle(resp)


def update_application_status(application_id, status):
    resp = requests.put(
        f"{API_BASE}/applications/{application_id}/status", json={"status": status}, timeout=TIMEOUT
    )
    return _handle(resp)


def get_ranked_candidates(job_id):
    resp = requests.get(f"{API_BASE}/jobs/{job_id}/ranked-candidates", timeout=TIMEOUT)
    return _handle(resp)


def send_message(application_id, sender_id, message):
    payload = {"application_id": application_id, "sender_id": sender_id, "message": message}
    resp = requests.post(f"{API_BASE}/messages", json=payload, timeout=TIMEOUT)
    return _handle(resp)


def get_messages(application_id):
    resp = requests.get(f"{API_BASE}/messages", params={"application_id": application_id}, timeout=TIMEOUT)
    return _handle(resp)


def get_hr_stats(hr_id):
    resp = requests.get(f"{API_BASE}/stats/hr/{hr_id}", timeout=TIMEOUT)
    return _handle(resp)


def get_candidate_stats(candidate_id):
    resp = requests.get(f"{API_BASE}/stats/candidate/{candidate_id}", timeout=TIMEOUT)
    return _handle(resp)


def is_api_up():
    try:
        resp = requests.get(f"{API_BASE}/health", timeout=3)
        return resp.ok
    except requests.exceptions.RequestException:
        return False
