"""
Database manager for the HR-Candidate Interaction Platform.
Uses SQLite for simplicity and zero external dependency setup.
"""
import sqlite3
import os
from contextlib import contextmanager
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(__file__), "hr_platform.db")


def get_connection():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


@contextmanager
def db_cursor(commit=False):
    conn = get_connection()
    cur = conn.cursor()
    try:
        yield cur
        if commit:
            conn.commit()
    finally:
        conn.close()


def init_db():
    """Create all tables if they do not already exist."""
    with db_cursor(commit=True) as cur:
        # Users table: shared by both HR and Candidate roles
        cur.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                full_name TEXT NOT NULL,
                email TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                role TEXT NOT NULL CHECK(role IN ('hr', 'candidate')),
                company_name TEXT,
                created_at TEXT NOT NULL
            )
        """)

        # Jobs posted by HR
        cur.execute("""
            CREATE TABLE IF NOT EXISTS jobs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                hr_id INTEGER NOT NULL,
                title TEXT NOT NULL,
                description TEXT NOT NULL,
                required_skills TEXT NOT NULL,
                min_experience REAL DEFAULT 0,
                location TEXT,
                status TEXT DEFAULT 'open' CHECK(status IN ('open', 'closed')),
                created_at TEXT NOT NULL,
                FOREIGN KEY (hr_id) REFERENCES users(id) ON DELETE CASCADE
            )
        """)

        # Resumes uploaded by candidates
        cur.execute("""
            CREATE TABLE IF NOT EXISTS resumes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                candidate_id INTEGER NOT NULL,
                file_path TEXT NOT NULL,
                original_filename TEXT NOT NULL,
                raw_text TEXT,
                parsed_name TEXT,
                parsed_email TEXT,
                parsed_phone TEXT,
                parsed_skills TEXT,
                parsed_experience_years REAL,
                parsed_education TEXT,
                uploaded_at TEXT NOT NULL,
                FOREIGN KEY (candidate_id) REFERENCES users(id) ON DELETE CASCADE
            )
        """)

        # Applications: candidate applies to a job with a specific resume
        cur.execute("""
            CREATE TABLE IF NOT EXISTS applications (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                job_id INTEGER NOT NULL,
                candidate_id INTEGER NOT NULL,
                resume_id INTEGER NOT NULL,
                match_score REAL,
                status TEXT DEFAULT 'applied' CHECK(
                    status IN ('applied', 'shortlisted', 'rejected', 'hired')
                ),
                applied_at TEXT NOT NULL,
                UNIQUE(job_id, candidate_id),
                FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE,
                FOREIGN KEY (candidate_id) REFERENCES users(id) ON DELETE CASCADE,
                FOREIGN KEY (resume_id) REFERENCES resumes(id) ON DELETE CASCADE
            )
        """)

        # Messages: simple HR <-> Candidate interaction thread per application
        cur.execute("""
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                application_id INTEGER NOT NULL,
                sender_id INTEGER NOT NULL,
                message TEXT NOT NULL,
                sent_at TEXT NOT NULL,
                FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE CASCADE,
                FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE
            )
        """)

    return True


def now_str():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


if __name__ == "__main__":
    init_db()
    print(f"Database initialized at {DB_PATH}")
