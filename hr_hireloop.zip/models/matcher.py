"""
Candidate-Job Matching Engine (scikit-learn)
---------------------------------------------
Uses TF-IDF vectorization + cosine similarity to score how well a
candidate's resume matches a job description. This is a classic,
interpretable, and fast approach well-suited to resume screening
without needing large pretrained models.

Score components:
  1. Text similarity (TF-IDF cosine) between resume text and job description+skills
  2. Skill overlap ratio (exact skill matches / required skills)
  3. Experience fit (candidate years vs minimum required)

Final score is a weighted blend, returned as a 0-100 match percentage.
"""
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


class CandidateJobMatcher:
    def __init__(self, text_weight=0.5, skill_weight=0.35, experience_weight=0.15):
        self.text_weight = text_weight
        self.skill_weight = skill_weight
        self.experience_weight = experience_weight
        self.vectorizer = TfidfVectorizer(
            stop_words="english",
            max_features=5000,
            ngram_range=(1, 2),
        )

    def _text_similarity(self, resume_text: str, job_text: str) -> float:
        """Cosine similarity between TF-IDF vectors of resume and job description."""
        if not resume_text.strip() or not job_text.strip():
            return 0.0
        try:
            tfidf_matrix = self.vectorizer.fit_transform([resume_text, job_text])
            sim = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])[0][0]
            return float(np.clip(sim, 0, 1))
        except ValueError:
            # Happens if vocabulary is empty after stop-word removal
            return 0.0

    def _skill_overlap(self, candidate_skills: list, required_skills: list) -> float:
        if not required_skills:
            return 1.0  # no specific requirement -> full score
        candidate_set = set(s.lower().strip() for s in candidate_skills)
        required_set = set(s.lower().strip() for s in required_skills)
        if not required_set:
            return 1.0
        matched = candidate_set.intersection(required_set)
        return len(matched) / len(required_set)

    def _experience_fit(self, candidate_years: float, min_required: float) -> float:
        if min_required <= 0:
            return 1.0
        if candidate_years >= min_required:
            return 1.0
        # Partial credit scaled by how close they are
        return max(0.0, candidate_years / min_required)

    def score(
        self,
        resume_text: str,
        candidate_skills: list,
        candidate_experience: float,
        job_description: str,
        required_skills: list,
        min_experience: float,
    ) -> dict:
        """
        Returns a dict with overall_score (0-100) and component breakdown.
        """
        job_full_text = job_description + " " + " ".join(required_skills)

        text_sim = self._text_similarity(resume_text, job_full_text)
        skill_sim = self._skill_overlap(candidate_skills, required_skills)
        exp_fit = self._experience_fit(candidate_experience, min_experience)

        overall = (
            self.text_weight * text_sim
            + self.skill_weight * skill_sim
            + self.experience_weight * exp_fit
        ) * 100

        matched_skills = list(
            set(s.lower() for s in candidate_skills)
            .intersection(set(s.lower() for s in required_skills))
        )
        missing_skills = list(
            set(s.lower() for s in required_skills)
            - set(s.lower() for s in candidate_skills)
        )

        return {
            "overall_score": round(overall, 2),
            "text_similarity": round(text_sim * 100, 2),
            "skill_match": round(skill_sim * 100, 2),
            "experience_fit": round(exp_fit * 100, 2),
            "matched_skills": sorted(matched_skills),
            "missing_skills": sorted(missing_skills),
        }

    def rank_candidates(self, candidates: list, job: dict) -> list:
        """
        candidates: list of dicts with keys:
            raw_text, skills (list), experience_years, candidate_id, resume_id, name
        job: dict with keys:
            description, required_skills (list), min_experience

        Returns candidates list sorted by overall_score descending,
        each augmented with the score breakdown.
        """
        results = []
        for c in candidates:
            result = self.score(
                resume_text=c.get("raw_text", ""),
                candidate_skills=c.get("skills", []),
                candidate_experience=c.get("experience_years", 0),
                job_description=job.get("description", ""),
                required_skills=job.get("required_skills", []),
                min_experience=job.get("min_experience", 0),
            )
            merged = {**c, **result}
            results.append(merged)

        results.sort(key=lambda x: x["overall_score"], reverse=True)
        return results


if __name__ == "__main__":
    # Quick sanity check
    matcher = CandidateJobMatcher()
    sample_resume = """
    Experienced Python developer with 4 years of experience in machine learning,
    data science, pandas, numpy, scikit-learn and Flask API development.
    """
    sample_job = "Looking for a Python developer with ML experience using scikit-learn and Flask."
    result = matcher.score(
        resume_text=sample_resume,
        candidate_skills=["python", "machine learning", "pandas", "numpy", "flask"],
        candidate_experience=4,
        job_description=sample_job,
        required_skills=["python", "flask", "scikit-learn", "sql"],
        min_experience=2,
    )
    print(result)
